# Handoff: High-Contrast Dark color system + wizard redesign

## Overview
A repo-wide visual refresh for **PWHL GM**. Two goals:
1. **Replace the color scheme** — the current vivid-violet-on-cool-navy palette
   reads as "team colors" (the user's words: *"giving Minnesota Frost"*). Move
   to **High-Contrast Dark**: neutral graphite surfaces, a calm desaturated
   sky-blue accent, and brighter text that actually meets WCAG AA. This is the
   centrally-themed direction the user chose.
2. **Redesign the create-league wizard** — especially the scoring/options step
   — and **fix the broken VP "?" tooltip**, which currently floats as an
   unanchored translucent box.

Apply the color system across **every page** (see `page-inventory.md`).

## About the design files
The files in `references/` are **design references created in HTML** — Design
Component prototypes showing the intended look and behavior. They are **not
production code to paste in.** The target repo is a **Next.js + React + TypeScript**
app (`rsamuels1/pwhl-fantasy`) that styles with **CSS variables in
`app/globals.css` plus inline `style={{…}}` objects**. Recreate the intended
look using *that* environment's patterns — i.e. update the CSS variables, sweep
the inline hexes, and rebuild the wizard component in `.tsx`.

## Fidelity
**High-fidelity.** Exact hex values, spacing, and typography are specified. The
color tokens and the component patterns should be matched precisely.
- Wizard + VP popover: `references/Create League Wizard.dc.html`
- League overview (in-season state): `references/League Overview.dc.html`
- Team matchup (active playoff DuelHero state): `references/Team Matchup.dc.html`
- Color schemes (chosen + alternatives considered): `references/Color Scheme Options.dc.html`
  — the app uses **"High-Contrast Dark."**

Flat PNG previews of every reference are in `screenshots/` (tall screens are
split into top/lower frames).

---

## Part 1 — Color system rollout

### Step A — token swap (re-skins most of the app)
Replace the `:root` block in `app/globals.css` with `globals.tokens.css` from
this bundle. Then make the three follow-up edits noted at the bottom of that
file. **The single most important one:** primary buttons currently use *white*
text on the accent. The new accent is **light** sky-blue, so button text must
flip to dark (`--accent-ink`). Anywhere text/icons sit on a solid accent fill,
they go dark.

### Step B — inline-hex sweep
The app hardcodes hundreds of hexes in inline styles. Run the find/replace pass
in `color-replacement-map.md` across `app/**` and `components/**`, then grep for
leftover `#` hexes and reconcile. Verify contrast on buttons/badges afterward.

### Step C — emoji removal
The brand brief bans emoji. Remove them everywhere per `emoji-removal.md` (the
wizard reference shows the replacement patterns: mono eyebrow labels, status
chips, a check badge for "done", an `i` for callouts). Do **not** hand-draw SVGs.

### The palette (quick reference)
| Token | Hex | Use |
|---|---|---|
| `--bg` | `#0a0a0c` | app background |
| `--bg-raised` | `#0e0f12` | inputs / wells |
| `--card` | `#16181c` | panels |
| `--card-hover` | `#1c1f24` | hover + **popovers** |
| `--text` | `#fafbfc` | primary text (15:1) |
| `--muted` | `#c9cfd9` | secondary (AA) |
| `--dim` | `#a4abb7` | labels (AA — fixes the old `#64748b` fail) |
| `--faint` | `#7d828d` | counters/hints |
| `--accent` | `#8fc1e8` | accent (sky) |
| `--accent-ink` | `#0a0a0c` | text ON accent fills |
| `--border` | `rgba(180,188,202,0.16)` | borders |
| `--green` | `#4ade80` | done/win/pass |
| `--red` | `#f87171` | error/loss |
| `--amber` | `#fbbf24` | warning/current |

Typography is unchanged: **Archivo** (body), **Saira Condensed** (stats/scores),
JetBrains Mono for data/labels in the tracker.

---

## Part 2 — Create-league wizard redesign
File: `app/create-league/CreateLeagueWizard.tsx`. Reference:
`references/Create League Wizard.dc.html` (open it; the step labels in the
progress bar jump between steps).

Internal step flow is unchanged (Name → Size → Season → Rules → Team → Invite →
Done; beta mode collapses to 4 displayed steps). Recreate each step's look in
the new palette, emoji-free. The **Rules/scoring step is the centerpiece**:

### Rules step — "rule sheet"
Replace the emoji-prefixed `RuleRow` list with a single bordered card divided
into labeled sections (each section header is an 11px JetBrains-Mono uppercase
eyebrow in `--dim`):
- **Roster** — slot **pills** (`3 F`, `2 D`, `1 UTIL`, `1 G`, `6 Bench`): the
  count in mono accent, the position in `--text`; `--bg-raised` pill with a
  `--border`. Sub-line: "UTIL takes any skater (F or D)."
- **Scoring** — a real **two-column table** (Skaters / Goalies), not wrapping
  chips. Stat in `--text` on the left, value in **mono `--green`** right-aligned
  (`+2.0` Goal, `+1.5` Assist, `+0.5` Power-play pt · `+5.0` Win, `+3.0` Shutout).
  Rows separated by hairline `--border-soft` top borders.
- **Standings** — "Ranked by **Victory Points (VP)**" followed by the redesigned
  "?" popover (below).
- **Playoffs** — right-aligned value "Top 4 teams · single elimination · no byes".
- **Season** — dynamic "2026-27 live PWHL · N teams" or "2025-26 replay · N teams".

Below the sheet: an accent-tinted info callout ("Scoring, roster slots, and
playoff format can all be changed from the admin panel before the draft.").

### VP popover — the "?" tooltip fix  ⚠
**Current bug** (`components/VpExplainer.tsx`): the panel is `position:absolute`
with **no positioned ancestor** and a translucent `var(--surface)` background,
so it renders as a see-through box in a random spot. Rebuild it as a proper
anchored popover:
- Wrap the `?` button in a `span` with **`position:relative; display:inline-flex`**.
- The panel is the button's child, `position:absolute; top:calc(100% + 11px);
  left:50%; transform:translateX(-50%)`, `width:296px`, `z-index:50`.
- **Solid** background `var(--card-hover)` (#1c1f24) — never translucent — with
  `border:1px solid var(--border)`, `border-radius:12px`,
  `box-shadow:0 14px 40px rgba(0,0,0,.55)`, a small 11px rotated-square **arrow**
  at the top, and a `popIn` fade (0.14s).
- Content: title "How Victory Points work", then the four VP rules as
  label/value rows (value in mono accent: `+2 VP` win, `+1 VP` tie, `+2 VP`
  highest score, `+1 VP` second-highest), then a footnote tying FP → matchup
  result → VP. (Keep the existing copy.)
- The `?` button itself: 19px circle; default = transparent w/ `--dim` border;
  **when open** = filled `--accent` with `--accent-ink` glyph.
- Optional polish: close on outside-click / `Esc`.

This component is reused on several screens, so fixing it once propagates.

---

---

## Part 3 — flagship screen redesigns
Two highest-traffic, highest-complexity screens, recreated at wizard fidelity in
High-Contrast Dark, emoji-free. Treat these as the canonical "after" for the
rest of the app's recolor — the same surface/border/accent/semantic decisions
shown here apply everywhere.

### League overview — `app/league/[leagueId]/page.tsx`
Reference: `references/League Overview.dc.html`. In-season state shown.
- **Two-column grid** (`.overview-grid`, 1fr / 360px, collapses < 880px). Left =
  primary modules, right = personal widgets.
- **Commissioner action strip** — amber (`--amber`) alert bar, top.
- **Playoff race** card — ranked rows; the playoff cut is a dashed divider after
  rank 4; my row gets `--accent-dim` fill + 2px `--accent` left border. Status
  chips: CLINCHED/IN = `--green` tint, BUBBLE = `--amber`, ELIM = `--red`, `N GB`
  = neutral. (Old code used `#5fa98c`/`#e3c989`/`#c2776c` — map to the tokens.)
- **League leaders** — two columns (scoring `--green`, underperforming `--red`),
  rank 1 marker in `--amber`.
- **My matchup widget** (right rail) — the ONE elevated card: subtle
  `linear-gradient(135deg,#1b2330,#16181c)` + `--accent-border`, big Saira score,
  win-rate bar in accent, solid-accent CTA with `--accent-ink` text. (Old code
  used a violet gradient + `#7c3aed` button — this is the key recolor.)
- **Lineup status** + **League activity** (token-tinted ACT_META chips) below it.
- **Commissioner note** — `--accent-dim` banner, full width at the bottom.

### Team matchup — `app/team/[teamId]/matchup/page.tsx` (the 66KB centerpiece)
Reference: `references/Team Matchup.dc.html`. Active **DuelHero** (1v1 playoff)
state shown — the richest of the hero's variants (the file also has `FieldHero`
for regular-season VTF and several empty/championship states; recolor them the
same way).
- **All-set banner** — `--green` tint, check badge (replaces the `✅` emoji).
- **DuelHero** — the signature element. Neutral graphite gradient
  `linear-gradient(135deg,#16181c,#141821,#0f1116)` + `--accent-border` + a faint
  sky radial glow (replaces the violet `#1b1346` gradient). 3-column
  you / VS / opponent grid. **Score colors stay semantic**: winning `--green`,
  losing `--red`, tied white — keep the `getScoreColor` logic, just swap hexes
  (`#34d399`→`--green`, `#f87171`→`--red`). My avatar = accent gradient w/ dark
  letter; opponent = neutral graphite. **Win-probability bar** in accent
  (`linear-gradient(90deg,#a6d0f0,#8fc1e8)`), keep the spring easing. Amber
  "Live scoring" / "Set lineup" status pill. FP→VP bridging note under the bar.
- **Live situation grid** (`.matchup-2col`) — left: *Playing tonight* (games
  grouped, players with 3px `--accent-deep` left rule + projected pts) and *Swing
  players* (mine `--green`, opp `--red`); right: *Roster status* widget (big
  projected FP in accent, set/locked line, accent CTA).
- **Recap card** — colored by result (`--green`/`--red`/neutral border), Saira
  score, top-performer + rank lines (drop the `⭐`/`🏆` emoji; "League-high
  score" goes amber text).
- **Rosters** (`.matchup-2col`) — two `RosterTable`s. Columns Slot / Player /
  Left / FP. Slot pill `--accent-dim` + accent text (was `rgba(91,33,182,0.6)`).
  Stat-breakdown chips `--green`/`--red` tint. "Left" games chip: 0 games =
  `--red` tint, else `--accent` tint. Bench rows dimmed (opacity ~0.62).

> Both screens depend on `VpExplainer` and `LogoShield`; fixing those once (see
> §VP popover) propagates here.

## State management (wizard)
Unchanged from current implementation. Reference DC mirrors it: `step` (1–7),
`name`, `teamName`, `maxTeams` (6/8/10/12), `isReplay`, `draftDate`, `isPublic`,
plus a `vpOpen` boolean for the popover. The real component also keeps
`loading`, `error`, `createdLeagueId`, `createdTeamId` and the beta-mode step
remapping (`getDisplayStep`/`getDisplayTotal`) — preserve all of that.

## Interactions & behavior
- Progress bar: 6 filled segments; segment `i` fills with `--accent` when
  `i < displayStep`. Step labels are clickable nav in the reference (optional in
  prod).
- Inputs: focus ring `border-color:var(--accent)` + `box-shadow:0 0 0 3px
  var(--accent-dim)`.
- Size/season options: selected = `--accent` border + `--accent-dim` fill +
  accent label; radio dot fills accent.
- Public toggle: 38×22 track, `--accent` when on, white knob translates 16px.
- Buttons: primary = `--accent` fill + `--accent-ink` text; secondary =
  transparent + `--border` + `--muted` text.

## Design tokens
See `globals.tokens.css` (full set) and the quick-reference table above.
Radii: inputs/pills 8–12px, cards 14–16px, popover 12px. Shadows: popover
`0 14px 40px rgba(0,0,0,.55)`.

## Assets
None new. Keep `components/LogoShield.tsx`. For any icons introduced during
emoji removal, adopt a standard React icon set (lucide/heroicons) — not emoji,
not hand-drawn SVG.

## Files in this bundle
- `globals.tokens.css` — drop-in `:root` + follow-up edits
- `color-replacement-map.md` — inline-hex find/replace sweep
- `emoji-removal.md` — emoji policy, inventory, replacements
- `page-inventory.md` — every route/component + per-screen notes
- `references/Create League Wizard.dc.html` — hi-fi wizard + VP popover
- `references/League Overview.dc.html` — hi-fi league overview (in-season)
- `references/Team Matchup.dc.html` — hi-fi team matchup (active playoff)
- `references/Color Scheme Options.dc.html` — chosen scheme + alternatives
- `screenshots/` — flat PNG previews of every reference

## Suggested order of work
1. `globals.tokens.css` swap + 3 follow-up edits → most of the app reskins.
2. Inline-hex sweep (`color-replacement-map.md`); verify button/badge contrast.
3. Emoji sweep (`emoji-removal.md`).
4. Rebuild `CreateLeagueWizard.tsx` + fix `VpExplainer.tsx`.
5. Rebuild the two flagship screens from their references (league overview,
   team matchup) + the wizard/popover, then walk `page-inventory.md` top to
   bottom recoloring the remaining [recolor] screens.
