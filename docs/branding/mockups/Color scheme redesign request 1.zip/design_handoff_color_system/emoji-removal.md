# Emoji removal

The brand brief (`branding-brief.md`) explicitly wants a professional,
front-office identity and bans the daily-fantasy / arcade look. Emoji are the
single biggest violation and appear throughout the UI. **Remove every emoji
from rendered UI surfaces** and replace per the rules below.

## Replacement rules
1. **Icon-prefix on a labeled row** (the most common case — e.g. the rule rows
   `👥 Roster`, `🏆 Scoring`): delete the emoji. The text label already names
   the row. Optionally add a small monospace uppercase eyebrow label instead
   (see the wizard rule sheet reference). **Do not** hand-draw replacement SVGs.
2. **Status / state glyphs** (`✅ ⏪ ⏱`): replace with a typographic mark in a
   colored chip — `✓` for done in a `--green` pill, a `LIVE` / `REPLAY`
   monospace tag for season mode, etc. (the wizard shows both patterns).
3. **Celebration / decorative** (`🎉 💡 🏒`): remove. For the "done" moment use
   a square check badge (`✓` on a tinted `--green` tile) as in the wizard
   step 7. For callouts (`💡 Next, you'll…`) use a small `i` in `--accent`.
4. If a genuine icon is needed, use the codebase's existing icon approach
   (it already has `components/LogoShield.tsx` and inline SVGs in places) — a
   lightweight icon set (lucide/heroicons) is the right call, not emoji.

## Known emoji locations (not exhaustive — grep to confirm)
| File | Emoji |
|---|---|
| `app/create-league/CreateLeagueWizard.tsx` | 🏒 ⏪ 👥 📊 🏆 📅 ⏱ 💡 🎉 ✓ — **already redesigned**, see reference HTML |
| `app/league/[leagueId]/page.tsx` | 🏆 🎉 and others (league overview) |
| `app/team/[teamId]/matchup/page.tsx` | various (matchup — largest file) |
| `components/sim/*` (WeekRecap, SeasonComplete, GMCommandCenter, PlayoffsPanel) | 🏆 🎉 ⏱ etc. |
| `components/WelcomeFlow.tsx`, `components/BetaWelcomeStep.tsx` | onboarding emoji |
| `components/RenewLeagueForm.tsx`, `components/WeekHighlights.tsx`, `components/RivalBadge.tsx` | misc |

> Run a Unicode-emoji grep across `app/**/*.tsx` and `components/**/*.tsx` to
> get the complete list before you start — they're sprinkled widely.

## Reference
`references/Create League Wizard.dc.html` is the canonical "after" for emoji
removal: every emoji there was replaced with a label, a chip, a mono tag, or a
clean check badge. Match that treatment elsewhere.
